<?php
echo password_hash(298638, PASSWORD_DEFAULT);
